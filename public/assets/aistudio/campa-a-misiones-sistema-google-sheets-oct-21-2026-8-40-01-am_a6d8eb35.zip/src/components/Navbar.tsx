import { 
  FileSpreadsheet, 
  Code2, 
  BookOpen, 
  ShieldCheck, 
  Download, 
  MapPin, 
  Users, 
  UserCheck, 
  Sparkles,
  ExternalLink,
  Cake,
  PartyPopper
} from 'lucide-react';
import { UsuarioAutorizado } from '../data/initialData';

interface NavbarProps {
  activeTab: 'directorio' | 'municipios' | 'usuarios' | 'appscript' | 'formulas';
  setActiveTab: (tab: 'directorio' | 'municipios' | 'usuarios' | 'appscript' | 'formulas') => void;
  currentUser: UsuarioAutorizado;
  onOpenLoginModal: () => void;
  onExportXLSX: () => void;
  onOpenBirthdaysDrawer?: () => void;
  birthdayCount?: number;
  onOpenFiestasModal?: () => void;
  fiestasCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  onOpenLoginModal,
  onExportXLSX,
  onOpenBirthdaysDrawer,
  birthdayCount = 0,
  onOpenFiestasModal,
  fiestasCount = 0,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-lg">
      {/* Top Banner with Misiones Province Colors Accent */}
      <div className="h-1.5 w-full bg-gradient-to-r from-red-600 via-sky-400 to-blue-700"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center shadow-md shadow-blue-500/20 text-white font-bold text-lg border border-blue-400/30">
              🏛️
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-base tracking-tight text-white flex items-center gap-1.5">
                  Campaña Electoral Misiones
                  <span className="bg-gradient-to-r from-blue-500/20 to-sky-500/20 text-sky-400 text-xs px-2 py-0.5 rounded-full border border-sky-500/30 font-medium">
                    79 Municipios
                  </span>
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Estructura Google Sheets, Auditoría Automatizada y Google Apps Script
              </p>
            </div>
          </div>

          {/* Quick Actions & Active Operator */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Birthday Notifications Button */}
            {onOpenBirthdaysDrawer && (
              <button
                onClick={onOpenBirthdaysDrawer}
                className="relative flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500/20 to-rose-500/20 hover:from-amber-500/30 hover:to-rose-500/30 border border-amber-400/40 text-amber-200 text-xs font-semibold shadow-xs transition cursor-pointer"
                title="Notificaciones: Cumpleaños de la semana en el Directorio"
              >
                <Cake className="w-4 h-4 text-amber-400 animate-bounce shrink-0" />
                <span className="hidden lg:inline text-amber-100 font-medium">Cumpleaños</span>
                {birthdayCount > 0 && (
                  <span className="bg-amber-400 text-amber-950 font-black px-1.5 py-0.5 rounded-full text-[10px] shadow-xs">
                    {birthdayCount}
                  </span>
                )}
              </button>
            )}

            {/* Fiestas Populares de Misiones Reminder Button */}
            {onOpenFiestasModal && (
              <button
                onClick={onOpenFiestasModal}
                className="relative flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-gradient-to-r from-rose-500/20 to-amber-500/20 hover:from-rose-500/30 hover:to-amber-500/30 border border-rose-400/40 text-rose-200 text-xs font-semibold shadow-xs transition cursor-pointer"
                title="Recordatorio: Fiestas Populares y Festivales de los 79 Municipios de Misiones"
              >
                <PartyPopper className="w-4 h-4 text-rose-400 shrink-0" />
                <span className="hidden lg:inline text-rose-100 font-medium">Fiestas Populares</span>
                {fiestasCount > 0 && (
                  <span className="bg-rose-500 text-white font-black px-1.5 py-0.5 rounded-full text-[10px] shadow-xs animate-pulse">
                    {fiestasCount}
                  </span>
                )}
              </button>
            )}

            {/* Operator info button */}
            <button
              onClick={onOpenLoginModal}
              title="Cambiar o validar credenciales de operador"
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700 text-xs text-slate-200 transition"
            >
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
              <div className="text-left hidden md:block">
                <div className="font-semibold text-white leading-tight truncate max-w-[140px] flex items-center gap-1">
                  {currentUser.rolSistema === 'Operador Universal' && (
                    <span title="Operador Universal">⭐</span>
                  )}
                  <span>{currentUser.nombre}</span>
                </div>
                <div className="text-[10px] text-slate-400">
                  {currentUser.rolSistema === 'Operador Universal'
                    ? 'Operador Universal (79 Mun.)'
                    : currentUser.municipioAsignado === 'TODOS'
                    ? 'Ámbito Provincial'
                    : `Municipio: ${currentUser.municipioAsignado}`}
                </div>
              </div>
              <ShieldCheck className="w-4 h-4 text-sky-400" />
            </button>

            {/* Export XLSX Button */}
            <button
              onClick={onExportXLSX}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-sm shadow-emerald-700/30 transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Descargar</span> .XLSX
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center space-x-1 sm:space-x-2 border-t border-slate-800/80 pt-1 pb-2 overflow-x-auto text-xs sm:text-sm">
          <button
            onClick={() => setActiveTab('directorio')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition whitespace-nowrap ${
              activeTab === 'directorio'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Pestaña 1: Directorio_General</span>
          </button>

          <button
            onClick={() => setActiveTab('municipios')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition whitespace-nowrap ${
              activeTab === 'municipios'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Pestaña 2: Municipios (79)</span>
          </button>

          <button
            onClick={() => setActiveTab('usuarios')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition whitespace-nowrap ${
              activeTab === 'usuarios'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>Pestaña 3: Usuarios_Autorizados</span>
          </button>

          <button
            onClick={() => setActiveTab('appscript')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition whitespace-nowrap ${
              activeTab === 'appscript'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Code2 className="w-4 h-4 text-amber-400" />
            <span>Código Apps Script (Code.gs)</span>
          </button>

          <button
            onClick={() => setActiveTab('formulas')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition whitespace-nowrap ${
              activeTab === 'formulas'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4 text-emerald-400" />
            <span>Estructura & Fórmulas</span>
          </button>
        </div>
      </div>
    </header>
  );
};
