import React, { useState, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { DirectorioView } from './components/DirectorioView';
import { MunicipiosView } from './components/MunicipiosView';
import { UsuariosView } from './components/UsuariosView';
import { AppsScriptStudio } from './components/AppsScriptStudio';
import { FormulasDocView } from './components/FormulasDocView';
import { LoginModalSimulator } from './components/LoginModalSimulator';
import { NotificacionesCumpleanosWidget } from './components/NotificacionesCumpleanosWidget';
import { FiestasPopularesModal } from './components/FiestasPopularesModal';
import { getActiveBirthdayNotifications } from './utils/birthdayUtils';
import { getFiestasProximas } from './data/fiestasPopularesMisiones';
import { 
  DIRECTORIO_INICIAL, 
  USUARIOS_INICIALES, 
  DirectorioItem, 
  UsuarioAutorizado 
} from './data/initialData';
import { exportFullSpreadsheet } from './utils/exportSpreadsheet';

export default function App() {
  const [activeTab, setActiveTab] = useState<'directorio' | 'municipios' | 'usuarios' | 'appscript' | 'formulas'>('directorio');
  const [directorio, setDirectorio] = useState<DirectorioItem[]>(DIRECTORIO_INICIAL);
  const [usuarios, setUsuarios] = useState<UsuarioAutorizado[]>(USUARIOS_INICIALES);
  const [currentUser, setCurrentUser] = useState<UsuarioAutorizado>(USUARIOS_INICIALES[0]);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isBirthdayDrawerOpen, setIsBirthdayDrawerOpen] = useState(false);
  const [isFiestasModalOpen, setIsFiestasModalOpen] = useState(false);
  const [candidateSearchQuery, setCandidateSearchQuery] = useState<string>('');

  const { records: birthdayRecords } = useMemo(() => {
    return getActiveBirthdayNotifications(directorio);
  }, [directorio]);

  const { mesActual } = useMemo(() => {
    return getFiestasProximas();
  }, []);

  const handleExportXLSX = () => {
    exportFullSpreadsheet(directorio, usuarios);
  };

  const handleSelectCandidateFromNotifications = (dni: string) => {
    setCandidateSearchQuery(dni);
    setActiveTab('directorio');
    setIsBirthdayDrawerOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-100/80 text-slate-900 flex flex-col font-sans">
      {/* Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onExportXLSX={handleExportXLSX}
        onOpenBirthdaysDrawer={() => setIsBirthdayDrawerOpen(true)}
        birthdayCount={birthdayRecords.length}
        onOpenFiestasModal={() => setIsFiestasModalOpen(true)}
        fiestasCount={mesActual.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'directorio' && (
          <DirectorioView
            directorio={directorio}
            setDirectorio={setDirectorio}
            currentUser={currentUser}
            initialSearchQuery={candidateSearchQuery}
          />
        )}

        {activeTab === 'municipios' && (
          <MunicipiosView directorio={directorio} />
        )}

        {activeTab === 'usuarios' && (
          <UsuariosView
            usuarios={usuarios}
            setUsuarios={setUsuarios}
            currentUser={currentUser}
            setCurrentUser={setCurrentUser}
          />
        )}

        {activeTab === 'appscript' && (
          <AppsScriptStudio />
        )}

        {activeTab === 'formulas' && (
          <FormulasDocView />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            🏛️ <strong>Sistema de Gestión Electoral • Provincia de Misiones</strong> (79 Municipios Oficiales)
          </span>
          <span className="font-mono text-[11px] text-slate-400">
            Google Sheets Architecture & Google Apps Script Automation
          </span>
        </div>
      </footer>

      {/* Login Modal Simulator */}
      <LoginModalSimulator
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        usuarios={usuarios}
        currentUser={currentUser}
        setCurrentUser={setCurrentUser}
      />

      {/* Global Birthday Notifications Drawer */}
      <NotificacionesCumpleanosWidget
        directorio={directorio}
        variant="sidebar-drawer"
        isOpen={isBirthdayDrawerOpen}
        onClose={() => setIsBirthdayDrawerOpen(false)}
        onSelectCandidate={handleSelectCandidateFromNotifications}
      />

      {/* Fiestas Populares de Misiones Reminder Modal */}
      <FiestasPopularesModal
        isOpen={isFiestasModalOpen}
        onClose={() => setIsFiestasModalOpen(false)}
        onFilterMunicipioInDirectorio={(mun) => {
          setCandidateSearchQuery(mun);
          setActiveTab('directorio');
          setIsFiestasModalOpen(false);
        }}
      />
    </div>
  );
}
